(() => {
  const form = document.querySelector('[data-static-quote-form]');
  if (!form) return;

  const button = form.querySelector('button[type="submit"]');
  const status = form.querySelector('.static-form-status');
  const originalLabel = button?.textContent || 'Saada';

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    if (form.elements._honey?.value) return;

    if (button) {
      button.disabled = true;
      button.textContent = 'Saadab…';
    }
    status.textContent = 'Päringu saatmine…';
    status.dataset.state = 'pending';

    try {
      const response = await fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { Accept: 'application/json' },
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      form.reset();
      status.textContent = 'Aitäh! Päring on saadetud. Võtame Teiega ühendust ühe tööpäeva jooksul.';
      status.dataset.state = 'success';
      document.dispatchEvent(new CustomEvent('wpformsAjaxSubmitSuccess', { detail: { formId: 153 } }));
    } catch {
      status.innerHTML = 'Päringu saatmine ei õnnestunud. Palun saatke e-kiri aadressile <a href="mailto:strumest@hotmail.com">strumest@hotmail.com</a> või helistage <a href="tel:+37255523176">+372 5552 3176</a>.';
      status.dataset.state = 'error';
    } finally {
      if (button) {
        button.disabled = false;
        button.textContent = originalLabel;
      }
    }
  });
})();

