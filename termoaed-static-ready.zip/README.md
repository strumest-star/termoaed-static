# TermoAed.ee staatiline migratsioon

See kaust sisaldab WordPressist sõltumatut staatilist koopiat. Põhilehed, pildid,
kujunduse failid, URL-id ja olemasolevad SEO metaandmed on säilitatud.

## Testversioon

- Kõigil HTML-lehtedel on praegu `noindex, nofollow` ning `robots.txt` keelab
  indekseerimise. See kaitseb ajutist testaadressi duplikaatsisu eest.
- Enne `termoaed.ee` DNS-i suunamist tuleb taastada algsed robots-metaandmed ja
  muuta `robots.txt` tootmisversioonile sobivaks.
- Tellimuskeskuse vorm saadab andmed FormSubmit kaudu aadressile
  `strumest@hotmail.com`. Teenus saadab esimese päringu järel sellele aadressile
  ühekordse kinnituskirja; enne kinnitamist vormi e-kirju edasi ei saadeta.

## Soovitatud majutus

GitHub Pages sobib siia paremini kui Cloudflare Pages, sest juurdomeeni saab
suunata Veebimajutuse DNS-is A/AAAA/CNAME-kirjetega ilma domeeni registripidajat
või nimeservereid vahetamata. Failiviited on suhtelised, seega töötab sama pakett
nii GitHubi projektiaadressil (`kasutajanimi.github.io/termoaed-static/`) kui ka
hiljem juurdomeenis `termoaed.ee`.

## Enne avalikuks lülitamist

1. Kontrolli lehed töölaua- ja mobiilivaates.
2. Saada üks testpäring ning kinnita FormSubmiti aktiveerimiskiri.
3. Eemalda testversiooni `noindex` ja ava `robots.txt`.
4. Lisa GitHub Pagesis kohandatud domeen `termoaed.ee` ja oota HTTPS-i valmimist.
5. Muuda Veebimajutuse DNS-kirjed alles siis, kui eelvaade on kontrollitud.
6. Hoia WordPressi majutus töös vähemalt 48–72 tundi pärast DNS-i muutmist.

